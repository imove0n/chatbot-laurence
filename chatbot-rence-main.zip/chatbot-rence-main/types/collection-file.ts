export interface CollectionFile {
  id: string
  name: string
  type: string
}
